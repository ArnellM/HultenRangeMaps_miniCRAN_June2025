#ifndef _testRcppModule_RCPP_HELLO_WORLD_H
#define _testRcppModule_RCPP_HELLO_WORLD_H

#include <Rcpp.h>

RcppExport SEXP rcpp_hello_world_cpp() ;

#endif
